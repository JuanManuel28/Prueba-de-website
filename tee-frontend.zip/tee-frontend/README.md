# tee-frontend

[![Build Status](https://drone.ambotics.io/api/badges/AmboticsCombine/tee-frontend/status.svg)](https://drone.ambotics.io/AmboticsCombine/tee-frontend)

La página principal + backend de el negocio TEE (Transporte Espectacular Especializado)
